# README

Simple maven application